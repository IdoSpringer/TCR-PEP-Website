


class LempelZiv:
    def __init__(self):
        self._encode_dict = self._build_ascii_dict()
        self._decode_dict = self._build_reverse_ascii_dict()
        self._counter = 128

    def _build_ascii_dict(self):
        ascii_dict = {}
        for i in range(128):
            ascii_dict[chr(i)] = format(i, '05d')
        return ascii_dict

    def _build_reverse_ascii_dict(self):
        ascii_dict = {}
        for i in range(128):
            ascii_dict[format(i, '05d')] = chr(i)
        return ascii_dict

    def _split(self, string):
        return_list = []
        inds = list(range(0, len(string), 5))
        for i in inds:
            return_list.append(string[i:i + 5])
        return return_list

    def encode(self, input_str: str):
        self.__init__()
        output = ""
        curr_str = ""

        for c in input_str:
            if curr_str + c in self._encode_dict:
                curr_str += c
            else:
                output += self._encode_dict[curr_str]
                self._encode_dict[format(self._counter, '05d')] = curr_str + c
                self._counter += 1
                curr_str = c
        return output + self._encode_dict[curr_str]

    def decode(self, input_code):
        self.__init__()
        old_c = ""
        output = ""

        for new_c in self._split(input_code):
            if new_c not in self._decode_dict:
                tmp = self._decode_dict[old_c]
                tmp += new_c
            else:
                tmp = self._decode_dict[new_c]

            output += tmp
            new_c = tmp[0]

            if old_c + new_c not in self._decode_dict:
                self._decode_dict[old_c + new_c] = format(self._counter, '03d')
                self._counter += 1
            old_c = new_c
        return output


if __name__ == "__main__":
    l = LempelZiv()
    l.decode(l.encode("abcd"))
    e = 0
